Hemos subido la ejecución del primer Mapa. Posteriormente, 
tuvimos la oporunidad de probar de vuelta pudiendo cambiar los parametros.
Se ha probado modificando delta a "por defecto" (0.05) para ver si la diferencia de resolución
se notaba mucho. Por los resultados podemos decir que se nota bastante. No obstante, no
sabemos hasta que punto es significativo a nivel espacial para futuros proyectos.

Para la prueba tambien hemos reducido el map_update_interval con el obetivo de realizar
más rapido el mapeo y poder dejar a otros compañeros. A parte de estos dos cambios, no hemos encontrado muchos
mas parametros significativos para nuestro problema.
para mas parametros: http://wiki.ros.org/gmapping