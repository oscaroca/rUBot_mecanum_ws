Hola!

Lamentablemente hemos tenido problemas a la hora de probar el código en el entorno virtual. 

Esto se debe a que el mundo de gazebo no carga los modelos, ni siquiera las paredes. Hemos puesto en el bashrc lo que toca (incluso lo hemos ajustado porque pareceria que es incorrecto por el /user/). De hecho, no hemos podido ni cargar mapas antiguos!
Uno de nosotros ha estado toda la semana intentandolo sin conseguir resultados. Otro de nosotros lo ha intentado esta mañana y tampoco ha conseguido hacerlo funcionar.

No obstante, hemos estado probando todo lo que hemos podido con las imagenes que hemos tomado con el robot en el laboratorio para garantizar el funcionamiento del algoritmo.

Adjuntamos las imagenes al igual que un ejemplo del procesado. Comentandolo con Eloi en clas,e nos hemos decantado por un pre-proceso mas complejo con la intención de poder agilizar la detección y cubrir algunos angulos que usando un detector de circulo hemos visto que llegaba a fallar.
Adicionalmente, la agilidad que nos brinda este algoritmo nos permitirá acomplarlo al modelo de deep learning que hagamos esta semana y con suerte conseguir al final un modelo de predicción mas robusto combinando ambas salidas.

COmo nota final, el codigo de signalDetection tiene diferentes algoritmos y parametros que nos hubiera gustado probar para ver si en pruebas reales/simuladas mejora la eficiencia y redimiento. Por desgracia no lo hemos podido hacer, asi que lo haremos el martes si cnseguimos solucionar el error o a muy malas lo probaremos ne hardware.

Añadimos tambien un notebook donde hemos hecho algunas pruebas de colab para demostrar que hemos trabajado todo lo que hemos podido.

De vuelta, lamentamos los problemas que pueda ocasionar. Nos hubiera gustado avisar antes, pero teniamos la esperanza que al menos alguno de los dos miembros del grupo consiguieran hacer funcionar el mundo de gazeboo.
